---
name: Aether Home System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  metric-num:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.03em
  metric-num-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style
The design system establishes a premium, authoritative, and frictionless command interface for high-end residential automation and IoT management. The interface merges architectural serenity with high-precision engineering telemetry. It is designed for discerning homeowners, smart building engineers, and remote property managers who require instant comprehension of real-time sensory data alongside effortless control of critical home systems.

The aesthetic fuses **Modern Technical Minimalism** with **Tonal Glassmorphism**:
- Dual-zone architecture: Deep structural slate frames the navigation and master controls, contrasting against an expansive, bright, high-clarity canvas for device orchestration.
- Precision telemetry: Data points are rendered with deliberate technical restraint—avoiding visual noise while highlighting vital state changes through luminous color cues.
- Tactile confidence: Surface transitions feel immediate, grounded, and physically calibrated, evoking the sensation of bespoke architectural hardware.

## Colors
The palette balances structural density with high-clarity data surfaces and purposeful status illumination:

- **Primary Electric Blue (`#2563eb` / `#3b82f6`):** The engine of intentional action. Applied strictly to interactive focus points, toggle activations, slider rails, and primary command triggers.
- **Secondary Slate Anchor (`#0f172a` base, `#1e293b` elevated):** Establishes the authoritative framing perimeter. Confined to persistent side navigation, telemetry tooltips, and deep contextual drawers.
- **Tertiary Vitality Emerald (`#10b981`):** Represents live connectivity, optimized energy efficiency, and operational health. Paired with soft pulse indicators for continuous real-time sync.
- **Sensor Amber Accent (`#f59e0b`):** Dedicated to ambient thermals, high-power draw alerts, climate heat cycles, and cautionary thresholds.
- **Canvas & Neutral Field (`#f8fafc` to `#ffffff`):** The device canvas utilizes a pristine, cool-tinted white base layered with subtle slate neutrals (`#e2e8f0` border rings, `#64748b` descriptive labels, and `#0f172a` primary metric text) ensuring long-session legibility without eye fatigue.

## Typography
Typography is set entirely in **Inter**, configured to leverage tabular figures (`tnum`) for dynamic sensor metrics, consumption tallies, and time series readouts. 

- **Display & Headline:** Tuned with subtle negative tracking (`-0.02em` to `-0.025em`) to produce a chiseled, architectural lockup across room headers and primary system states.
- **Metric Values:** Styled using bold weights and tight line heights to ensure telemetry numerals stand out as dominant focal anchors within dashboard cards.
- **Sensor Labels & Meta:** Rendered in small, uppercase-tracked configurations (`label-sm`) for immediate hardware zone identification, communication protocols (e.g., `ZIGBEE 3.0`, `ZWAVE PLUS`), and quick diagnostic status.

## Layout & Spacing
The layout relies on a split-structure fluid grid orchestrated around an asymmetric control architecture:

- **Structural Anchor (Sidebar):** Fixed-width navigation panel (280px desktop, 72px collapsed tablet) grounded in dark slate (`#0f172a`), insulating global navigation, multi-zone switching, and high-level health alerts.
- **Workspace Canvas:** A 12-column fluid grid on desktop with a default `1.5rem` gutter and `2rem` outer canvas padding. Components snap to 3-column (sensor modules), 4-column (climate and lighting pods), or 6-column configurations (telemetry charts and security video feeds).
- **Responsive Adaptations:**
  - **Desktop (≥ 1280px):** Permanent dark master sidebar, 12-column layout, unconstrained telemetry tables.
  - **Tablet (768px – 1279px):** Sidebar collapses to an icon rail (`72px`), grid switches to 6-column, outer margin reduces to `1.5rem`.
  - **Mobile (< 768px):** Off-canvas drawer navigation, 1-column dynamic stack, metric panels collapse into horizontally swipable telemetry carousels with `1rem` outer margins.

## Elevation & Depth
Elevation merges sharp physical isolation with layered optical depth:

- **Ground Layer (`#f8fafc`):** The non-elevated workspace foundation supporting background metric charts and canvas dividers.
- **Level 1 (Card & Module Layer):** Pure white surfaces (`#ffffff`) bordered by a precision `1px` translucent edge (`rgba(15, 23, 42, 0.06)`). Elevated by an ambient, tinted shadow: `0 1px 3px rgba(15, 23, 42, 0.04), 0 6px 16px -4px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Active Overlays & Glass Trays):** Utilized for floating environmental controllers, quick-action flyouts, and active telemetry pins. Features a frosted background (`rgba(255, 255, 255, 0.85)` with a `16px` backdrop-blur), framed by a light-catching border (`rgba(255, 255, 255, 0.6)` inner inset and `rgba(15, 23, 42, 0.08)` outer ring), paired with a deep diffused shadow: `0 12px 32px -8px rgba(15, 23, 42, 0.08)`.
- **Deep Slate Overlays:** Dedicated popovers on the dark navigation frame utilize `#1e293b` with a crisp `1px` stroke of `rgba(255, 255, 255, 0.08)` and high-contrast ambient shadowing.

## Shapes
A roundedness factor of `2` underpins the modern physical aesthetic:

- **Dashboard Pods & Panels:** Configured with `rounded-2xl` (`1rem` to `1.5rem`), creating refined containers that soften high-density metrics and technical indicators.
- **Interactive Controls & Toggles:** Radii scale down to `rounded-lg` (`0.5rem`) for form inputs, stepper buttons, and segmented pickers to preserve functional sharpness.
- **Telemetry Badges & Indicators:** Pill shapes (`rounded-full`) are reserved strictly for binary status dots, active mode badges, and discrete sensor tags.

## Components

### Metric & Sensor Telemetry Cards
- **Base Structure:** `rounded-2xl` pure white container with a `1px` border of `rgba(15, 23, 42, 0.06)`. Internal padding adheres to `space-lg` (`1.5rem`).
- **Telemetry Header:** Sensor category label in uppercase `label-sm` with slate muted coloring (`#64748b`), accompanied by a live ping indicator badge (a `6px` dot of `#10b981` with an ambient glow).
- **Metric Readout:** Tabular numeric presentation in `metric-num` paired with an inline, low-contrast measurement unit (e.g., `kWh`, `°F`, `PPM`).

### Buttons & Interactive Triggers
- **Primary Action:** Solid electric blue (`#2563eb`) with white text, `rounded-lg`, zero border, and a subtle bottom-edge shadow. Hover shifts to `#1d4ed8` with immediate 150ms ease transitions.
- **Secondary / Device Toggle:** Neutral surface with a `1px` border in `#e2e8f0`. Hover activates a subtle wash of `rgba(37, 99, 235, 0.04)` and darkens the border to `#cbd5e1`.
- **Destructive / Panic Triggers:** Crisp border in `#fee2e2` with `#ef4444` text, shifting to solid red only on active confirmation.

### High-Tech Status Chips & Pills
- **Online/Active:** Pill-shaped pill badge with a translucent green fill (`rgba(16, 185, 129, 0.1)`), emerald text (`#059669`), and an active ping ring.
- **Environmental Alert (Thermal/Air Quality):** Translucent amber fill (`rgba(245, 158, 11, 0.1)`), warm amber text (`#d97706`), signaling elevated readings without causing panic.

### Toggles, Sliders & Control Dials
- **Master Switches:** Custom tactile toggles; track shifts from muted gray (`#e2e8f0`) to electric blue (`#2563eb`). The sliding thumb uses a crisp white disc with an inset shadow for a tactile look.
- **Range & Climate Sliders:** Continuous fluid sliders featuring a `6px` track height, dual-color fill, and an elevated `18px` circular control knob with a micro electric-blue halo ring on focus.

### Data Tables & Device Inventories
- **Row Styling:** Minimalist, divider-separated rows (`#f1f5f9`). Alternating fills are omitted; subtle row highlights (`#f8fafc`) trigger on hover.
- **Cell Content:** Tabular figures aligned to the right for telemetry outputs; hardware IDs and zones formatted in monospaced-tuned `Inter` for fast visual scanning.